import { Card } from "@/components/ui/card"
import { MapPin } from "lucide-react"

export function ContactoMapSection() {
  return (
    <section className="py-20 bg-black text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <MapPin className="h-12 w-12 mx-auto mb-4 text-white" />
            <h2 className="font-heading text-3xl md:text-4xl font-bold mb-4 font-light">Ubicación y Cobertura</h2>
          </div>

          <Card className="overflow-hidden border border-gray-800 bg-gray-900">
            <div
              className="w-full h-96 bg-cover bg-center"
              style={{ backgroundImage: "url(/images/mapa1.png)" }}
            />
            <div className="p-8 bg-gray-900">
              <p className="text-center text-lg text-gray-300 leading-relaxed">
                Atendemos proyectos en todo el país.{" "}
                <span className="font-semibold text-white">Sin costos de transporte en La Paz</span>; otros
                departamentos sujetos a coordinación y viáticos.
              </p>
            </div>
          </Card>
        </div>
      </div>
    </section>
  )
}
