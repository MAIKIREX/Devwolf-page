import { Card } from "@/components/ui/card"
import { Building2, Clock, Mail, Phone } from "lucide-react"

export function ContactoInfoSection() {
  return (
    <section className="py-20 bg-black text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-heading text-3xl md:text-4xl font-bold mb-4 font-light">Información de Contacto</h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Estamos disponibles para atender tus consultas y proyectos
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          <Card className="p-6 text-center border border-gray-800 bg-gray-900 text-white hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-4">
              <Building2 className="h-8 w-8 text-white" />
            </div>
            <h3 className="font-heading text-lg font-semibold mb-2 font-light">Empresa</h3>
            <p className="text-gray-300 text-sm">Devwolf INGENIERÍA & TECNOLOGÍA</p>
            <p className="text-gray-300 text-sm mt-2">NIT: 680646031</p>
          </Card>

          <Card className="p-6 text-center border border-gray-800 bg-gray-900 text-white hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-4">
              <Phone className="h-8 w-8 text-white" />
            </div>
            <h3 className="font-heading text-lg font-semibold mb-2 font-light">WhatsApp / Celular</h3>
            <a href="https://wa.me/59178855457" className="text-gray-100 hover:underline font-medium">
              78855457
            </a>
          </Card>

          <Card className="p-6 text-center border border-gray-800 bg-gray-900 text-white hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-4">
              <Mail className="h-8 w-8 text-white" />
            </div>
            <h3 className="font-heading text-lg font-semibold mb-2 font-light">Email</h3>
            <a
              href="mailto:innova.ingenieriaytecnologia@gmail.com"
              className="text-gray-100 hover:underline text-sm break-all"
            >
              innova.ingenieriaytecnologia@gmail.com
            </a>
          </Card>

          <Card className="p-6 text-center border border-gray-800 bg-gray-900 text-white hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-4">
              <Clock className="h-8 w-8 text-white" />
            </div>
            <h3 className="font-heading text-lg font-semibold mb-2 font-light">Horario</h3>
            <p className="text-gray-300 text-sm">Lun–Vie</p>
            <p className="text-gray-300 text-sm font-medium">8:00–17:00</p>
            <p className="text-gray-400 text-xs mt-2">Fines de semana con coordinación</p>
          </Card>
        </div>
      </div>
    </section>
  )
}
