import { Button } from "@/components/ui/button"
import Link from "next/link"

export function ContactoCtaSection() {
  return (
    <section className="py-20 bg-black text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="font-heading text-3xl md:text-4xl font-bold mb-6 font-light">
          ¿Listo para iniciar tu proyecto con Devwolf?
        </h2>
        <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
          Obtén una cotización personalizada y descubre cómo podemos ayudarte
        </p>
        <Button asChild size="lg" variant="outline" className="text-lg px-8 py-6 border-white/30 text-white">
          <Link href="#formulario">Solicitar cotización</Link>
        </Button>
      </div>
    </section>
  )
}
